//go:build linux && amd64

package main

import (
	"encoding/json"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestPreparationEntryRefusesWorkflows(t *testing.T) {
	for _, op := range []string{"run", "resume", "worker", "check", "history", "validate", "research-identity"} {
		if err := command([]string{op, "unused"}); err == nil || !strings.Contains(err.Error(), "unavailable") {
			t.Fatalf("accepted %s: %v", op, err)
		}
	}
	if err := command(nil); err == nil {
		t.Fatal("accepted absent arguments")
	}
}
func TestPreparationRefusesExpiredOrExistingRoot(t *testing.T) {
	c := preparationConfig{Schema: "buildopt.preparation-observation/config/v1", RunRoot: t.TempDir(), MaxRunNS: int64(time.Hour), MaxBytes: 16 << 30, MinimumFreeBytes: 40 << 30}
	source := filepath.Join(t.TempDir(), "manifest.json")
	var m Manifest
	if err := readJSON("../inputs/original-manifest.json", &m); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(source, jsonBytes(m), 0600); err != nil {
		t.Fatal(err)
	}
	b, err := bind(source)
	if err != nil {
		t.Fatal(err)
	}
	c.Original = b
	if _, err = preparationManifest(c); err == nil || !strings.Contains(err.Error(), "already exists") {
		t.Fatalf("existing root: %v", err)
	}
	c.RunRoot = filepath.Join(t.TempDir(), "absent")
	c.DeadlineUTC = time.Now().Add(-time.Minute).Format(time.RFC3339Nano)
	if _, err = preparationManifest(c); err == nil || !strings.Contains(err.Error(), "expired") {
		t.Fatalf("expired: %v", err)
	}
	if _, err = os.Stat(c.RunRoot); !os.IsNotExist(err) {
		t.Fatal("refusal created a root")
	}
}
func TestPreparationTracePreservesCopyAndFailure(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "source")
	dst := filepath.Join(root, "destination")
	if err := os.Mkdir(src, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "content"), []byte("retained content\n"), 0640); err != nil {
		t.Fatal(err)
	}
	trace, err := os.Create(filepath.Join(root, "trace"))
	if err != nil {
		t.Fatal(err)
	}
	old := os.Stdout
	os.Stdout = trace
	defer func() { os.Stdout = old; trace.Close() }()
	traceID = 0
	traceStack = nil
	expected, err := bind(src)
	if err != nil {
		t.Fatal(err)
	}
	if err = copyTree(src, dst); err != nil {
		t.Fatal(err)
	}
	got, err := bind(dst)
	if err != nil || got.SHA256 != expected.SHA256 {
		t.Fatalf("copy changed: %v", err)
	}
	if err = checkBinding(Binding{dst, strings.Repeat("0", 64)}); err == nil {
		t.Fatal("binding failure was hidden")
	}
	if _, err = trace.Seek(0, 0); err != nil {
		t.Fatal(err)
	}
	decoder := json.NewDecoder(trace)
	events := []map[string]any{}
	for {
		var event map[string]any
		err = decoder.Decode(&event)
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatal(err)
		}
		events = append(events, event)
	}
	if len(events) != 4 || events[0]["kind"] != "copy-tree" || events[1]["event"] != "RETURN" || events[2]["kind"] != "check-binding" || len(traceStack) != 0 {
		t.Fatalf("unexpected spans: %v", events)
	}
}
