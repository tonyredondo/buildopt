//go:build linux && amd64

// This diagnostic has no workflow, worker, comparison or resume entry point.
package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"time"
)

type preparationConfig struct {
	Schema           string  `json:"schema"`
	Original         Binding `json:"original"`
	RunRoot          string  `json:"runRoot"`
	DeadlineUTC      string  `json:"deadlineUTC"`
	MaxRunNS         int64   `json:"maxRunNS"`
	MaxBytes         int64   `json:"maxBytes"`
	MinimumFreeBytes uint64  `json:"minimumFreeBytes"`
}

var traceID int
var traceStack []int
var copyTraceDepth int

// Spans add counter reads and pipe writes, not file scans or synchronization.
func preparationTrace(kind string, detail any) func() {
	traceID++
	id := traceID
	parent := 0
	if len(traceStack) > 0 {
		parent = traceStack[len(traceStack)-1]
	}
	emit := func(event string) {
		counters, err := observeRecorder()
		if err != nil {
			panic(err)
		}
		if err = json.NewEncoder(os.Stdout).Encode(map[string]any{"event": event, "id": id, "parent": parent, "kind": kind, "detail": detail, "resources": counters}); err != nil {
			panic(err)
		}
	}
	emit("BEGIN")
	traceStack = append(traceStack, id)
	return func() { emit("RETURN"); traceStack = traceStack[:len(traceStack)-1] }
}

func preparationManifest(c preparationConfig) (Manifest, error) {
	var m Manifest
	if c.Schema != "buildopt.preparation-observation/config/v1" || !filepath.IsAbs(c.RunRoot) || c.MaxRunNS <= 0 || c.MaxRunNS > int64(time.Hour) || c.MaxBytes != 16<<30 || c.MinimumFreeBytes != 40<<30 {
		return m, errors.New("invalid diagnostic bounds")
	}
	if err := checkBinding(c.Original); err != nil {
		return m, err
	}
	if err := readJSON(c.Original.Path, &m); err != nil {
		return m, err
	}
	if m.Driver != "GRADLE" || m.Mode != leanResearchMode || m.Phase != "QUALIFICATION" || len(m.Outputs.Projectors) != 0 || len(m.History) != 4 || m.History[0].Commit != "1e1b40d2f3ddbad40cdeba2f9e2241440785c3fe" || m.RunRoot == c.RunRoot {
		return m, errors.New("requires the frozen development control inputs and a fresh diagnostic root")
	}
	if _, err := os.Lstat(c.RunRoot); !os.IsNotExist(err) {
		return m, errors.New("diagnostic root already exists or cannot be checked")
	}
	deadline, err := time.Parse(time.RFC3339Nano, c.DeadlineUTC)
	if err != nil || !time.Now().Before(deadline) {
		return m, errors.New("diagnostic deadline expired")
	}
	m.RunRoot = c.RunRoot
	m.Limits.DeadlineUTC = c.DeadlineUTC
	m.Limits.MaxRunNS = c.MaxRunNS
	m.Limits.MaxBytes = c.MaxBytes
	m.Limits.MinimumFreeBytes = c.MinimumFreeBytes
	m.Limits.MaxWorkflowStarts = 0
	m.Limits.MaxGradleStarts = 0
	m.Limits.RetryPairs = 0
	return m, nil
}

func prepareOnly(path string) error {
	var config preparationConfig
	if err := readJSON(path, &config); err != nil {
		return err
	}
	m, err := preparationManifest(config)
	if err != nil {
		return err
	}
	defer preparationTrace("preparation", m.RunRoot)()
	if err = os.Mkdir(m.RunRoot, 0700); err != nil {
		return err
	}
	for _, name := range []string{"costs", "states", "recorder-resources"} {
		if err = os.Mkdir(filepath.Join(m.RunRoot, name), 0700); err != nil {
			return err
		}
	}
	b, err := saveBound(filepath.Join(m.RunRoot, "diagnostic-manifest.json"), m)
	if err != nil {
		return err
	}
	r := &runner{manifest: m, binding: b, start: stamp(), sessions: map[string]workerSession{}, states: map[string]StatePin{}, stateBindings: map[string]Binding{}, builds: map[string]map[string]bool{}, generations: map[string]int{}}
	if err = r.initialize(1); err != nil {
		return err
	}
	// The previous control refused its first request: only N's preflight ran.
	state := r.states[armKey(1, "N")]
	return r.phase(Cost{ID: "diagnostic-N-preflight", Class: "research", Purpose: "source-input-state-proof", Replication: 1, Ordinal: 0, Arm: "N"}, func() error {
		if err := checkInputs(m); err != nil {
			return err
		}
		if err := verifyState(m, state); err != nil {
			return err
		}
		_, err := verifySource(m.CommonGit, filepath.Join(state.Root, "repo"), state.Revision, patchesFor(m, state), m.GeneratedPaths)
		return err
	})
}

func command(args []string) error {
	if len(args) != 2 || args[0] != "prepare-only" {
		return errors.New("usage: preparation-observer prepare-only CONFIG; workflow entry points are unavailable")
	}
	return prepareOnly(args[1])
}
func main() {
	if err := command(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
