# Historical replay result

Decision: `FIXTURE_VERIFIED`. Phase: `QUALIFICATION`. Subject: `local-fixture`.

Workflows started: 6. Gradle invocations observed: 0, including 0 nested. Reserved Gradle starts: 0; unresolved reservations: 0.

| Replication | Complete | Comparable / scheduled | Net seconds | Net percent | Payback ordinal | Research seconds | Study elapsed seconds |
|---|---|---|---|---|---|---|---|
| 1 | true | 2 / 2 | -0.055756 | -17.854 | -1 | 21.134410 | 22.104372 |

Primary requests include candidate admission/application. Research time includes source checkout, evidence capture, synchronization and gaps inside each replication. The final offline checker/export runs after that interval; its command receipt is separate research evidence. Human costs must be reported separately. Qualification and engineering results cannot establish public-repository value.

Raw ledger: [attempts](attempts.jsonl), [costs](costs.jsonl), [manifest](manifest.json), [result](result.json).
