//go:build linux && amd64

package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestResearchReadinessAdmission(t *testing.T) {
	m := fixtureManifest(t, 4)
	m.Mode = leanResearchMode
	// A real owner must never use the fixture bootstrap exemption.
	m.Driver = "GRADLE"
	if err := validateResearchMeasurement(m); err == nil || !strings.Contains(err.Error(), "own readiness") {
		t.Fatalf("missing receipt accepted: %v", err)
	}
	proof := filepath.Join(filepath.Dir(m.RunRoot), "proof.log")
	mustWrite(t, proof, []byte("local test evidence\n"))
	checks := map[string]Binding{}
	for _, name := range []string{"invocation-output", "failure-fallback", "cancellation-closure", "source-drift", "missing-result", "readiness-admission", "affinity"} {
		checks[name] = bound(t, proof)
	}
	local := ResearchLocalProof{Schema: "buildopt.lean-research/local-proof/v1", ExitCode: 0, Executable: m.Executable, Package: m.Package, Checks: checks, OwnerStarts: 0}
	localpath := filepath.Join(filepath.Dir(m.RunRoot), "local.json")
	mustWrite(t, localpath, jsonBytes(local))
	receipt := ResearchReadiness{Schema: "buildopt.lean-research/readiness/v1", Mode: leanResearchMode, Identity: researchIdentity(m), LocalProof: bound(t, localpath)}
	path := filepath.Join(filepath.Dir(m.RunRoot), "readiness.json")
	set := func() { mustWrite(t, path, jsonBytes(receipt)); b := bound(t, path); m.MeasurementReadiness = &b }
	set()
	if err := validateResearchMeasurement(m); err != nil {
		t.Fatal(err)
	}
	for _, phase := range []string{"ENGINEERING", "CONFIRMATION"} {
		m.Phase = phase
		if validateResearchMeasurement(m) == nil {
			t.Fatalf("%s admitted without its own trials", phase)
		}
	}
	m.Phase = "QUALIFICATION"
	m.Environment["JAVA_TOOL_OPTIONS"] = "-javaagent:diagnostic.jar"
	if validateResearchMeasurement(m) == nil {
		t.Fatal("diagnostic agent admitted")
	}
	delete(m.Environment, "JAVA_TOOL_OPTIONS")
	receipt.Identity = strings.Repeat("0", 64)
	set()
	if validateResearchMeasurement(m) == nil {
		t.Fatal("different sources admitted")
	}
	receipt.Identity = researchIdentity(m)
	receipt.Schema = "historical-overhead-pass"
	set()
	if validateResearchMeasurement(m) == nil {
		t.Fatal("old receipt admitted")
	}
	receipt.Schema = "buildopt.lean-research/readiness/v1"
	set()
	if err := os.Remove(proof); err != nil {
		t.Fatal(err)
	}
	if validateResearchMeasurement(m) == nil {
		t.Fatal("missing required evidence admitted")
	}
}

func TestResearchTrialAdmission(t *testing.T) {
	m := fixtureManifest(t, 101)
	m.Mode = leanResearchMode
	for _, control := range []bool{true, false} {
		name := "prefix"
		count := 21
		if control {
			name = "control"
			count = 4
		}
		t.Run(name, func(t *testing.T) {
			prior := m
			prior.RunRoot = filepath.Join(filepath.Dir(m.RunRoot), name)
			prior.ExecutionEnd = count - 1
			prior.Replications = 1
			if err := os.MkdirAll(filepath.Join(prior.RunRoot, "costs"), 0700); err != nil {
				t.Fatal(err)
			}
			if control {
				prior.History = append([]Revision{}, m.History[17:21]...)
				for i := range prior.History {
					prior.History[i].Ordinal = i
				}
				combined := m.Baseline
				combined.Files = append(append([]FilePatch{}, m.Baseline.Files...), m.Candidate.Files...)
				prior.ControlBaseline = &combined
			} else {
				prior.Phase = "ENGINEERING"
				prior.PrefixEnd = 20
			}
			manifest := filepath.Join(prior.RunRoot, "manifest.json")
			mustWrite(t, manifest, jsonBytes(prior))
			result := RunResult{Schema: resultSchema, ManifestSHA256: bound(t, manifest).SHA256, WorkflowStarts: 2 * count, ActualGradleStarts: 2 * count, Slots: [][]Slot{{}}, Replications: []Economics{}, Reasons: []string{}}
			for i := 0; i < count; i++ {
				duration := int64(80e9)
				if control {
					duration = 100e9
				}
				result.Slots[0] = append(result.Slots[0], Slot{Ordinal: i, Class: comparable, NativeNS: 100e9, CandidateNS: duration, Attempts: []string{}})
			}
			rp := filepath.Join(prior.RunRoot, "result.json")
			mustWrite(t, rp, jsonBytes(result))
			closure := ResearchClosure{Schema: "buildopt.lean-research/closure/v1", ManifestSHA256: result.ManifestSHA256, ExitCode: 0, LivePairs: count, IndependentPairs: count, Closed: true, Evidence: []Binding{bound(t, manifest)}}
			cp := filepath.Join(prior.RunRoot, "closure.json")
			mustWrite(t, cp, jsonBytes(closure))
			proof := ResearchTrialProof{Manifest: bound(t, manifest), Result: bound(t, rp), Closure: bound(t, cp), Costs: bound(t, filepath.Join(prior.RunRoot, "costs"))}
			if err := validateResearchTrial(m, &proof, control); err != nil {
				t.Fatal(err)
			}
			closure.Closed = false
			mustWrite(t, cp, jsonBytes(closure))
			proof.Closure = bound(t, cp)
			if validateResearchTrial(m, &proof, control) == nil {
				t.Fatal("open native processes admitted")
			}
			closure.Closed = true
			mustWrite(t, cp, jsonBytes(closure))
			proof.Closure = bound(t, cp)
			if control {
				result.Slots[0][1].CandidateNS = 120e9
			} else {
				for i := range result.Slots[0] {
					result.Slots[0][i].CandidateNS = 100e9
				}
			}
			mustWrite(t, rp, jsonBytes(result))
			proof.Result = bound(t, rp)
			if validateResearchTrial(m, &proof, control) == nil {
				t.Fatal("negative control/prefix admitted")
			}
			result.Slots[0] = result.Slots[0][:count-1]
			mustWrite(t, rp, jsonBytes(result))
			proof.Result = bound(t, rp)
			if validateResearchTrial(m, &proof, control) == nil {
				t.Fatal("missing scheduled result admitted")
			}
		})
	}
}
