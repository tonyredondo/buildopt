//go:build linux && amd64 && replay_integration

package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestResearchCLIAndMissingResults(t *testing.T) {
	m := runnableFixture(t, 2, "success")
	path := filepath.Join(filepath.Dir(m.RunRoot), "manifest.json")
	mustWrite(t, path, jsonBytes(m))
	c := exec.Command(m.Executable.Path, "run", path)
	if b, err := c.CombinedOutput(); err != nil {
		t.Fatalf("actual CLI: %v %s", err, b)
	}
	var result RunResult
	if err := readJSON(filepath.Join(m.RunRoot, "result.json"), &result); err != nil {
		t.Fatal(err)
	}
	if result.WorkflowStarts != 4 || result.Decision != "FIXTURE_VERIFIED" {
		t.Fatal("incomplete CLI result")
	}
	output := filepath.Join(m.RunRoot, "attempts/r1-000-g0-N/outputs/000000")
	if err := os.Remove(output); err != nil {
		t.Fatal(err)
	}
	c = exec.Command(m.Executable.Path, "check", m.RunRoot)
	if b, err := c.CombinedOutput(); err == nil {
		t.Fatalf("missing output accepted: %s", b)
	}
	// Admission must reject an owner before creating even a run directory.
	m.Driver = "GRADLE"
	m.RunRoot = filepath.Join(filepath.Dir(m.RunRoot), "rejected-owner")
	mustWrite(t, path, jsonBytes(m))
	c = exec.Command(m.Executable.Path, "run", path)
	if b, err := c.CombinedOutput(); err == nil || !strings.Contains(string(b), "own readiness") {
		t.Fatalf("missing receipt was not refused first: %v %s", err, b)
	}
	if _, err := os.Stat(m.RunRoot); !os.IsNotExist(err) {
		t.Fatal("owner run created before readiness")
	}
}
