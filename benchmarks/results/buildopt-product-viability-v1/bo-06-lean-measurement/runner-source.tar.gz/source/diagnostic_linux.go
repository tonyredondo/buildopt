//go:build linux && amd64

package main

import "golang.org/x/sys/unix"

type diagnosticCPUTime struct {
	UserNS   int64 `json:"userNS"`
	SystemNS int64 `json:"systemNS"`
}

func diagnosticCPU() diagnosticCPUTime {
	var r unix.Rusage
	if err := unix.Getrusage(unix.RUSAGE_SELF, &r); err != nil {
		panic(err)
	}
	return diagnosticCPUTime{r.Utime.Nano(), r.Stime.Nano()}
}
