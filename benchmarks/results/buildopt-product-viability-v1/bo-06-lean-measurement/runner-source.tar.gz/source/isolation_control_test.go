//go:build linux && amd64 && replay_integration && replay_gradle

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"
)

// This task-only driver is diagnostic. It never returns a readiness/value pass.
func TestIsolationFixture(t *testing.T) {
	m := gradleFixture(t, 1, `tasks.register('replay') { doLast {
 Thread.sleep(300)
 file('out').mkdirs()
 file('out/proof.txt').text = 'diagnostic-output-v1\n'
} }`)
	m.Subject = "cpu-isolation-fixture"
	m.Limits.MaxWorkflowStarts = 2
	m.Limits.MaxGradleStarts = 2
	runDaemonDiagnostic(t, m, false)
}

func TestIsolationOwner(t *testing.T) {
	var m Manifest
	if err := readJSON(os.Getenv("BUILDOPT_DIAGNOSTIC_MANIFEST"), &m); err != nil {
		t.Fatal(err)
	}
	if m.Subject != "elasticsearch-cpu-isolation-control" || m.Phase != "QUALIFICATION" || len(m.History) != 1 || m.ExecutionEnd != 0 || m.Limits.MaxWorkflowStarts != 32 || m.Limits.MaxGradleStarts != 32 || m.Limits.MaxRequestNS != int64(900*time.Second) || len(m.Candidate.Files) != 0 {
		t.Fatal("diagnostic scope differs")
	}
	if err := checkBinding(m.Overhead); err != nil {
		t.Fatal(err)
	}
	runDaemonDiagnostic(t, m, true)
}

// Only a vanished process identity is a recoverable snapshot gap. A missing
// owned cgroup, permission error or unrelated I/O error still stops observation.
func diagnosticExitedProcess(err error) bool {
	var pathError *os.PathError
	if !errors.As(err, &pathError) || !(os.IsNotExist(err) || errors.Is(err, syscall.ESRCH)) {
		return false
	}
	parts := strings.Split(pathError.Path, "/")
	if len(parts) != 4 || parts[0] != "" || parts[1] != "proc" {
		return false
	}
	pid, e := strconv.Atoi(parts[2])
	if e != nil || pid <= 0 {
		return false
	}
	return parts[3] == "stat" || parts[3] == "cgroup" || parts[3] == "cmdline"
}

func sampleOwnedProcesses(worker workerSession, path string, stop <-chan struct{}, finished chan<- error) {
	sampleOwnedProcessesWithObserver(worker, path, stop, finished, cgroupProcesses)
}

func sampleOwnedProcessesWithObserver(worker workerSession, path string, stop <-chan struct{}, finished chan<- error, observe func(string) ([]ProcessIdentity, error)) {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		finished <- err
		return
	}
	defer f.Close()
	encoder := json.NewEncoder(f)
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-stop:
			finished <- nil
			return
		case <-ticker.C:
			begin := stamp()
			ps, e := observe(worker.Cgroup)
			if e != nil {
				// Short-lived compiler/worker processes may exit after enumeration.
				// Preserve the missing snapshot; all other observation errors fail.
				if diagnosticExitedProcess(e) {
					if err := encoder.Encode(map[string]interface{}{"begin": begin, "end": stamp(), "gap": "PROCESS_EXITED_DURING_SNAPSHOT", "error": e.Error()}); err != nil {
						finished <- err
						return
					}
					continue
				}
				finished <- e
				return
			}
			rows := []map[string]interface{}{}
			for _, p := range ps {
				row := map[string]interface{}{"identity": p}
				masks, affinityErr := threadAffinities(p.PID)
				if affinityErr != nil {
					row["affinityError"] = affinityErr.Error()
				} else {
					row["threadAffinities"] = masks
				}

				for _, name := range []string{"stat", "schedstat", "io"} {
					raw, e := os.ReadFile(fmt.Sprintf("/proc/%d/%s", p.PID, name))
					if e != nil {
						row[name+"Error"] = e.Error()
					} else {
						row[name] = string(raw)
					}
				}
				rows = append(rows, row)
			}
			group := map[string]string{}
			for _, name := range []string{"cpu.stat", "cpu.pressure", "io.pressure", "memory.pressure"} {
				raw, e := os.ReadFile(filepath.Join("/sys/fs/cgroup", worker.Cgroup, name))
				if e != nil {
					group[name] = "UNAVAILABLE: " + e.Error()
				} else {
					group[name] = string(raw)
				}
			}
			if e := encoder.Encode(map[string]interface{}{"begin": begin, "end": stamp(), "processes": rows, "cgroup": group}); e != nil {
				finished <- e
				return
			}
		}
	}
}

func runDaemonDiagnostic(t *testing.T, m Manifest, owner bool) {
	t.Helper()
	phase := os.Getenv("BUILDOPT_DIAGNOSTIC_ROOT")
	if !filepath.IsAbs(phase) {
		t.Fatal("explicit diagnostic root required")
	}
	r := runFixture(t, m)
	if err := beginReplication(m.RunRoot, 1); err != nil {
		t.Fatal(err)
	}
	status := "INCOMPLETE"
	defer func() {
		if err := endReplication(m.RunRoot, 1, 0, status, "old/new supervisor control; identical native baseline; never readiness or product value"); err != nil {
			t.Error(err)
		}
	}()
	if err := r.initialize(1); err != nil {
		t.Fatal(err)
	}
	identities := []map[string]string{}
	for _, arm := range []string{"N", "I"} {
		repo := filepath.Join(m.RunRoot, "r1", arm, "repo")
		identity := map[string]string{"repository": repo, "locator": filepath.Join(phase, "..", "task-state.json"), "remoteTarget": "read-only subject history; no publication", "arm": arm}
		for key, args := range map[string][]string{"head": {"rev-parse", "HEAD"}, "branch": {"branch", "--show-current"}, "commonGit": {"rev-parse", "--path-format=absolute", "--git-common-dir"}} {
			value, err := gitAt(repo, args...)
			if err != nil {
				t.Fatal(err)
			}
			identity[key] = strings.TrimSpace(string(value))
		}
		identities = append(identities, identity)
	}
	mustWrite(t, filepath.Join(m.RunRoot, "worktree-identities.json"), jsonBytes(identities))
	arms := []string{"N", "I"}
	cycles := 1
	label := "fixture"
	if owner {
		arms = []string{"N", "I"}
		cycles = 16
		label = "owner"
	}
	workers := map[string]workerSession{}
	seen := map[string]map[string]bool{"N": {}, "I": {}}
	daemon := map[string]ProcessIdentity{}
	sequence := 0
	for index, arm := range arms {
		dir := filepath.Join(m.RunRoot, "sessions", "diagnostic-"+arm)
		if err := os.Mkdir(dir, 0700); err != nil {
			t.Fatal(err)
		}
		w, err := startWorker(m, r.binding, 1, arm, index+1, dir)
		if err != nil {
			t.Fatal(err)
		}
		workers[arm] = w
		t.Cleanup(func() {
			if err := w.stop(); err != nil {
				t.Error(err)
			}
		})
	}
	for cycle := 0; cycle < cycles; cycle++ {
		order := arms
		if owner {
			order = armOrder(1, cycle)
		}
		for _, arm := range order {
			sequence++
			if err := r.guard(); err != nil {
				t.Fatal(err)
			}
			id := fmt.Sprintf("diagnostic-%02d-%s-plain", sequence, arm)
			dir := filepath.Join(m.RunRoot, "attempts", id)
			if err := os.Mkdir(dir, 0700); err != nil {
				t.Fatal(err)
			}
			args, env := workflow(m, 1, arm, dir)
			plain := []string{}
			for i := 0; i < len(args); i++ {
				if args[i] == "--init-script" {
					i++
					continue
				}
				plain = append(plain, args[i])
			}
			q := ProcessRequest{recordSchema, id, filepath.Join(m.RunRoot, "r1", arm, "repo"), plain, env, dir, m.Limits.MaxRequestNS}
			if owner {
				patches := []Patch{m.Baseline}
				if _, err := verifySource(m.CommonGit, q.Directory, m.History[0].Commit, patches, m.GeneratedPaths); err != nil {
					t.Fatal(err)
				}
			}
			mustWrite(t, filepath.Join(dir, "reservation.json"), jsonBytes(q))
			stop := make(chan struct{})
			finished := make(chan error, 1)
			go sampleOwnedProcesses(workers[arm], filepath.Join(dir, "proc-samples.jsonl"), stop, finished)
			begin := stamp()
			end := Stamp{}
			native, err := workers[arm].invoke(q, func(ProcessReceipt) { end = stamp() })
			close(stop)
			sampleErr := <-finished
			if err != nil || sampleErr != nil {
				t.Fatalf("request: %v sampler: %v", err, sampleErr)
			}
			if native.ExitCode != 0 || native.Outcome != "EXITED" {
				t.Fatalf("native failure: %+v", native)
			}
			logs, builds, err := collectGradleLogs(filepath.Join(m.RunRoot, "r1", arm), dir, native, seen[arm])
			if err != nil {
				t.Fatal(err)
			}
			c := Capture{DaemonLogs: logs, GradleBuilds: builds}
			if _, err := checkGradleCommands(m, c, native, filepath.Join(m.RunRoot, "r1", arm), seen[arm]); err != nil {
				t.Fatal(err)
			}
			if len(builds) != 1 {
				t.Fatal("hidden or duplicate Gradle command")
			}
			seen[arm][builds[0].ID] = true
			if cycle == 0 {
				p, err := processIdentity(builds[0].PID)
				if err != nil {
					t.Fatal(err)
				}
				if p.Cgroup != workers[arm].Cgroup || !strings.Contains(strings.Join(p.Command, " "), "org.gradle.launcher.daemon.bootstrap.GradleDaemon") {
					t.Fatal("daemon ownership mismatch")
				}
				daemon[arm] = p
				mustWrite(t, filepath.Join(phase, "inputs", label+"-"+arm+"-daemon.json"), jsonBytes(p))
			} else if builds[0].PID != daemon[arm].PID || !sameProcess(daemon[arm]) {
				t.Fatal("daemon restarted")
			}
			out, err := os.ReadFile(filepath.Join(dir, "stdout.log"))
			if err != nil {
				t.Fatal(err)
			}
			if !strings.Contains(string(out), "BUILD SUCCESSFUL") {
				t.Fatal("native success missing")
			}
			if !owner {
				proof, err := os.ReadFile(filepath.Join(q.Directory, "out/proof.txt"))
				if err != nil || string(proof) != "diagnostic-output-v1\n" {
					t.Fatalf("fixture output: %v", err)
				}
				mustWrite(t, filepath.Join(dir, "proof.txt"), proof)
			}
			sample := map[string]interface{}{"schema": "buildopt.daemon-diagnostic/sample/v1", "arm": arm, "cycle": cycle, "sequence": sequence, "warmup": owner && cycle < 8, "jfrActive": false, "begin": begin, "end": end, "native": bound(t, filepath.Join(dir, "native-finish.json")), "logs": logs, "builds": builds, "daemon": daemon[arm]}
			mustWrite(t, filepath.Join(dir, "sample.json"), jsonBytes(sample))
			fmt.Printf("DIAGNOSTIC request=%d arm=%s cycle=%d nativeMS=%.3f pid=%d\n", sequence, arm, cycle, float64(native.End.NS-native.Start.NS)/1e6, daemon[arm].PID)
		}
	}
	for _, arm := range arms {
		if err := workers[arm].stop(); err != nil {
			t.Fatal(err)
		}
	}
	if sequence != m.Limits.MaxWorkflowStarts {
		t.Fatal("incomplete fixed allocation")
	}
	if owner {
		for _, arm := range arms {
			patches := []Patch{m.Baseline}
			if _, err := verifySource(m.CommonGit, filepath.Join(m.RunRoot, "r1", arm, "repo"), m.History[0].Commit, patches, m.GeneratedPaths); err != nil {
				t.Fatal(err)
			}
		}
	}
	status = "SUPERVISOR_CONTROL_COMPLETE"
	mustWrite(t, filepath.Join(m.RunRoot, "diagnostic-result.json"), jsonBytes(map[string]interface{}{"status": status, "requests": sequence, "owner": owner, "readinessQualified": false, "valueQualified": false}))
}
