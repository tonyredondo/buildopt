//go:build linux && amd64 && replay_integration
package main
import("encoding/json";"fmt";"os";"path/filepath";"testing";"time")
func TestRetainedObjectSizing(t *testing.T) {
 manifest:=os.Getenv("BUILDOPT_RETAINED_SAMPLE"); if manifest=="" { t.Skip("explicit real-artifact sample required") }
 raw,err:=os.ReadFile(manifest);if err!=nil {t.Fatal(err)}
 var sources []string;if err:=json.Unmarshal(raw,&sources);err!=nil {t.Fatal(err)}
 if len(sources)!=128 {t.Fatal("sample must have 128 files")}
 root:=t.TempDir(); store:=filepath.Join(root,"store")
 for _,mode:=range []string{"reference","populate","reuse"} {
  dir:=filepath.Join(root,mode);if err:=os.Mkdir(dir,0700);err!=nil{t.Fatal(err)}
  files:=[]fileCopy{};for i,src:=range sources {files=append(files,fileCopy{src,filepath.Join(dir,fmt.Sprint(i))})}
  begin:=time.Now();var err error
  if mode=="reference" {err=copyEvidenceFiles(files)}else{err=retainOutputFiles(files,store)}
  if err!=nil{t.Fatal(err)};if err:=syncDir(dir);err!=nil{t.Fatal(err)}
  elapsed:=time.Since(begin)
  for _,f:=range files {a,err:=fileDigest(f.Source);if err!=nil{t.Fatal(err)};b,err:=fileDigest(f.Destination);if err!=nil||a!=b{t.Fatal("copy mismatch",err)};x,_:=os.Stat(f.Source);y,_:=os.Stat(f.Destination);if os.SameFile(x,y){t.Fatal("source shares evidence")}}
  t.Logf("mode=%s files=%d elapsedNS=%d exactIndependent=true",mode,len(files),elapsed.Nanoseconds())
 }
}
