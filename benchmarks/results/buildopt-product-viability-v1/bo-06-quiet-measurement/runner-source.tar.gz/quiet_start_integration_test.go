//go:build linux && amd64 && replay_integration

package main

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func quietFixture(t *testing.T) Manifest {
	t.Helper()
	m := runnableFixture(t, 1, "success")
	enableQuiet(t, &m)
	m.Limits.MaxWorkflowStarts = 2
	m.Limits.RetryPairs = 0
	m.Limits.MaxRunNS = int64(7 * time.Minute)
	return m
}

func assertQuietClosure(t *testing.T, m Manifest, launches int) {
	t.Helper()
	files, err := filepath.Glob(filepath.Join(m.RunRoot, "attempts", "*", "native-pid.json"))
	if err != nil || len(files) != launches {
		t.Fatalf("native starts: %v %v; want %d", files, err, launches)
	}
	configs, err := filepath.Glob(filepath.Join(m.RunRoot, "sessions", "*", "worker-config.json"))
	if err != nil || len(configs) == 0 {
		t.Fatalf("missing real owned session: %v", err)
	}
	for _, path := range configs {
		var closure SessionClosure
		if err := readJSON(filepath.Join(filepath.Dir(path), "closed.json"), &closure); err != nil {
			t.Fatal(err)
		}
		processes, err := cgroupProcesses(closure.Cgroup)
		if !os.IsNotExist(err) && (err != nil || len(processes) != 0) {
			t.Fatalf("session not closed: %s %v %v", closure.Unit, processes, err)
		}
	}
}

// This uses real pressure reads, real elapsed time, the actual worker socket,
// user systemd and native fixture processes. No clock or pressure is replaced.
func TestQuietRunnerActualPair(t *testing.T) {
	m := quietFixture(t)
	r := runFixture(t, m)
	if err := r.execute(1, 0, -1); err != nil {
		t.Fatal(err)
	}
	result, err := writeResult(m.RunRoot)
	if err != nil {
		t.Fatal(err)
	}
	if result.Decision != "FIXTURE_VERIFIED" || result.WorkflowStarts != 2 || len(result.Slots[0]) != 1 {
		t.Fatalf("incomplete actual quiet pair: %+v", result)
	}
	if err := checkResult(m.RunRoot, filepath.Join(m.RunRoot, "result.json")); err != nil {
		t.Fatal(err)
	}
	assertQuietClosure(t, m, 2)
	for _, arm := range []string{"N", "I"} {
		id := "r1-000-g0-" + arm
		path := filepath.Join(m.RunRoot, "attempts", id, "quiet-start.json")
		var receipt QuietReceipt
		if err := readJSON(path, &receipt); err != nil {
			t.Fatal(err)
		}
		if receipt.End.NS-receipt.Begin.NS < fixedQuietPolicy().WindowNS {
			t.Fatal("actual wait was shorter than the full window")
		}
		t.Logf("%s: %.3fs wait, %d retained pressure samples", arm, float64(receipt.End.NS-receipt.Begin.NS)/1e9, len(receipt.Samples))
	}
	// Reuse the completed pair to exercise independent reconstruction failures.
	// Each test restores its own bytes; there are no additional workflow starts.
	for _, relative := range []string{
		"attempts/r1-000-g0-N/quiet-start.json",
		"costs/r1-000-g0-N-quiet-start.json",
		"recorder-resources/r1-000-g0-N-capture.json",
	} {
		t.Run("missing-"+filepath.Base(relative), func(t *testing.T) {
			path := filepath.Join(m.RunRoot, relative)
			raw, err := os.ReadFile(path)
			if err != nil {
				t.Fatal(err)
			}
			info, err := os.Stat(path)
			if err != nil {
				t.Fatal(err)
			}
			if err := os.Remove(path); err != nil {
				t.Fatal(err)
			}
			defer func() {
				if err := os.WriteFile(path, raw, info.Mode().Perm()); err != nil {
					t.Fatal(err)
				}
			}()
			if err := checkResult(m.RunRoot, filepath.Join(m.RunRoot, "result.json")); err == nil {
				t.Fatal("independent checker accepted missing quiet evidence")
			}
		})
	}
	if err := checkResult(m.RunRoot, filepath.Join(m.RunRoot, "result.json")); err != nil {
		t.Fatal(err)
	}
}

func TestQuietRunnerStopsWithoutNativeLaunch(t *testing.T) {
	for _, kind := range []string{"read-error", "cancelled", "deadline", "stale-at-launch"} {
		t.Run(kind, func(t *testing.T) {
			m := quietFixture(t)
			if kind == "deadline" {
				m.Limits.MaxRunNS = int64(8 * time.Second)
			}
			r := runFixture(t, m)
			want := "OBSERVATION_FAILED"
			switch kind {
			case "read-error":
				r.quietClock = &quietClock{stamp, func() (PressureSample, error) { return PressureSample{}, errors.New("fixture pressure read failed") }, waitQuiet}
			case "cancelled":
				ctx, cancel := context.WithCancel(context.Background())
				cancel()
				r.quietContext = ctx
				want = "INTERRUPTED"
			case "deadline":
				want = "NOT_QUIET_TIMEOUT"
			case "stale-at-launch":
				want = "QUIET_START"
				r.fault = func(point, _ string) {
					if point == "quiet-ready" {
						time.Sleep(1100 * time.Millisecond)
					}
				}
			}
			err := r.execute(1, 0, -1)
			if err == nil || !strings.Contains(err.Error(), "NOT_RUN_QUIET") {
				t.Fatalf("quiet refusal missing: %v", err)
			}
			var receipt QuietReceipt
			base := filepath.Join(m.RunRoot, "attempts", "r1-000-g0-N")
			if err := readJSON(filepath.Join(base, "quiet-start.json"), &receipt); err != nil {
				t.Fatal(err)
			}
			if receipt.Decision != want {
				t.Fatalf("decision %s; want %s", receipt.Decision, want)
			}
			if kind == "stale-at-launch" {
				var rejected QuietRejection
				if err := readJSON(filepath.Join(base, "quiet-launch-rejected.json"), &rejected); err != nil || !strings.Contains(rejected.Reason, "stale") {
					t.Fatalf("worker did not retain stale rejection: %+v %v", rejected, err)
				}
			}
			costs, err := loadCosts(m.RunRoot)
			if err != nil {
				t.Fatal(err)
			}
			found := false
			for _, cost := range costs {
				if cost.Purpose == "quiet-start" {
					found = cost.Class == "research" && !cost.InsideEnvelope && cost.DurationNS > 0
				}
			}
			if !found {
				t.Fatal("failed wait was not charged to research")
			}
			if err := checkRecorderResources(m, costs); err != nil {
				t.Fatal(err)
			}
			assertQuietClosure(t, m, 0)
			if _, _, _, err := resumeRunner(m.RunRoot); err == nil {
				t.Fatal("quiet refusal became an automatic retry")
			}
			t.Logf("%s retained: %s; zero native starts", kind, receipt.Decision)
		})
	}
}
