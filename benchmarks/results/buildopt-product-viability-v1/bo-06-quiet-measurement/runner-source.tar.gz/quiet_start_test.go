//go:build linux && amd64

package main

import (
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func quietStamp(ns int64) Stamp { return Stamp{ns, "2026-09-15T00:00:00Z", "test-boot"} }

func pressureSamples(start int64, count int, perSecondUS int64) []PressureSample {
	rows := []PressureSample{}
	for i := 0; i < count; i++ {
		at := quietStamp(start + int64(i)*1e9)
		rows = append(rows, PressureSample{at, at, map[string]int64{"cpu": int64(i) * perSecondUS, "io": int64(i) * perSecondUS, "memory": int64(i) * perSecondUS}})
	}
	return rows
}

func enableQuiet(t *testing.T, m *Manifest) {
	t.Helper()
	m.Mode = leanResearchMode
	path := filepath.Join(filepath.Dir(m.RunRoot), "quiet-policy.json")
	mustWrite(t, path, jsonBytes(fixedQuietPolicy()))
	b := bound(t, path)
	m.QuietStart = &b
}

func TestQuietPressureParsing(t *testing.T) {
	for _, raw := range []string{"", "full total=2", "some total=-1", "some total=x", "some total=2 total=3"} {
		if _, err := pressureTotal(raw); err == nil {
			t.Fatalf("accepted %q", raw)
		}
	}
	n, err := pressureTotal("some avg10=1.0 total=123\nfull total=50\n")
	if err != nil || n != 123 {
		t.Fatalf("counter: %d %v", n, err)
	}
}

func TestQuietWindowConditions(t *testing.T) {
	for _, tc := range []struct {
		name     string
		count    int
		pressure int64
		want     bool
	}{{"empty", 0, 0, false}, {"short", 30, 0, false}, {"quiet", 31, 0, true}, {"boundary", 31, 100000, true}, {"above", 31, 100001, false}} {
		t.Run(tc.name, func(t *testing.T) {
			got, _ := quietWindow(pressureSamples(1e12, tc.count, tc.pressure), fixedQuietPolicy())
			if got != tc.want {
				t.Fatalf("ready %v", got)
			}
		})
	}
}

func TestQuietWindowRejectsRecentFaults(t *testing.T) {
	changes := map[string]func([]PressureSample){
		"burst":      func(s []PressureSample) { s[30].TotalsUS["io"] = 900000 },
		"missing":    func(s []PressureSample) { delete(s[20].TotalsUS, "memory") },
		"reset":      func(s []PressureSample) { s[20].TotalsUS["cpu"] = 1 },
		"read-delay": func(s []PressureSample) { s[20].Begin.NS -= 100e6 + 1 },
		"clock":      func(s []PressureSample) { s[20].Begin.Boot = "other" },
		"overlap":    func(s []PressureSample) { s[20].Begin.NS = s[19].End.NS - 1 },
		"reversed":   func(s []PressureSample) { s[20], s[21] = s[21], s[20] },
	}
	for name, change := range changes {
		t.Run(name, func(t *testing.T) {
			s := pressureSamples(1e12, 31, 0)
			change(s)
			if ok, why := quietWindow(s, fixedQuietPolicy()); ok {
				t.Fatal("accepted", why)
			}
		})
	}
	s := pressureSamples(1e12, 31, 0)
	s = append(s[:10], s[14:]...)
	if ok, _ := quietWindow(s, fixedQuietPolicy()); ok {
		t.Fatal("gap accepted")
	}
}

func TestQuietWaitRetainsBusyObservations(t *testing.T) {
	start := int64(1e12)
	now := start
	reads := 0
	clock := quietClock{now: func() Stamp { return quietStamp(now) }, wait: func(_ context.Context, d time.Duration) error { now += int64(d); return nil }}
	clock.read = func() (PressureSample, error) {
		reads++
		n := int64(0)
		if reads > 1 {
			n = 900000
		}
		at := quietStamp(now)
		return PressureSample{at, at, map[string]int64{"cpu": 0, "io": n, "memory": 0}}, nil
	}
	receipt := observeQuiet(context.Background(), QuietReceipt{Begin: quietStamp(start), DeadlineNS: start + 40e9}, fixedQuietPolicy(), clock, func() error { return nil })
	if receipt.Decision != "QUIET_START" || len(receipt.Samples) != 32 || receipt.End.NS-start != 31e9 {
		t.Fatalf("lost busy interval: %+v", receipt)
	}
}

func TestQuietWaitStopsBeforeLaunch(t *testing.T) {
	for _, name := range []string{"busy", "read-error", "cancel", "limit", "late-read"} {
		t.Run(name, func(t *testing.T) {
			start := int64(1e12)
			now := start
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			clock := quietClock{now: func() Stamp { return quietStamp(now) }, wait: func(_ context.Context, d time.Duration) error { now += int64(d); return nil }}
			clock.read = func() (PressureSample, error) {
				if name == "read-error" {
					return PressureSample{}, os.ErrPermission
				}
				if name == "late-read" {
					now += 40e9
				}
				if name == "cancel" {
					cancel()
				}
				at := quietStamp(now)
				n := (now - start) / 1000
				return PressureSample{at, at, map[string]int64{"cpu": n, "io": n, "memory": n}}, nil
			}
			guard := func() error {
				if name == "limit" {
					return errors.New("disk floor")
				}
				return nil
			}
			r := observeQuiet(ctx, QuietReceipt{Begin: quietStamp(start), DeadlineNS: start + 35e9}, fixedQuietPolicy(), clock, guard)
			want := map[string]string{"busy": "NOT_QUIET_TIMEOUT", "read-error": "OBSERVATION_FAILED", "cancel": "INTERRUPTED", "limit": "NOT_RUN_LIMIT", "late-read": "NOT_QUIET_TIMEOUT"}[name]
			if r.Decision != want {
				t.Fatalf("got %s, want %s", r.Decision, want)
			}
			if name == "busy" && len(r.Samples) != 35 {
				t.Fatal("lost timeout observations")
			}
		})
	}
}

func TestQuietPolicyBindingAndCompatibility(t *testing.T) {
	m := fixtureManifest(t, 1)
	m.Mode = leanResearchMode
	legacy := jsonBytes(m)
	identity := researchIdentity(m)
	if _, err := readQuietPolicy(m); err != nil {
		t.Fatal(err)
	}
	if strings.Contains(string(legacy), "quietStart") {
		t.Fatal("legacy JSON changed")
	}
	enableQuiet(t, &m)
	if _, err := readQuietPolicy(m); err != nil {
		t.Fatal(err)
	}
	if researchIdentity(m) == identity {
		t.Fatal("quiet policy omitted from measurement identity")
	}
	m.Mode = "P"
	if _, err := readQuietPolicy(m); err == nil {
		t.Fatal("another mode admitted")
	}
	m.Mode = leanResearchMode
	p := fixedQuietPolicy()
	p.WindowNS = 1
	mustWrite(t, m.QuietStart.Path, jsonBytes(p))
	b := bound(t, m.QuietStart.Path)
	m.QuietStart = &b
	if _, err := readQuietPolicy(m); err == nil {
		t.Fatal("weaker window admitted")
	}
	var decoded Manifest
	if err := decodeStrict([]byte(strings.TrimSuffix(strings.TrimSpace(string(legacy)), "}")+`,"quietStart":null}`), &decoded); err == nil || !strings.Contains(err.Error(), "null") {
		t.Fatalf("null policy did not reach strict decoding: %v", err)
	}
}

func TestQuietLaunchUsesObservationTimeAndRequestIdentity(t *testing.T) {
	m := fixtureManifest(t, 1)
	enableQuiet(t, &m)
	dir := filepath.Join(filepath.Dir(m.RunRoot), "attempt")
	if err := os.Mkdir(dir, 0700); err != nil {
		t.Fatal(err)
	}
	q := ProcessRequest{Attempt: "r1-000-g0-N", Evidence: dir}
	hash := strings.Repeat("a", 64)
	samples := pressureSamples(1e12, 31, 0)
	base := QuietReceipt{Schema: "buildopt.quiet-start/receipt/v1", Attempt: q.Attempt, ManifestSHA256: hash, Policy: *m.QuietStart, Begin: samples[0].Begin, End: quietStamp(1e12 + 30e9 + 1e6), DeadlineNS: 1e12 + 180e9, Decision: "QUIET_START", Samples: samples}
	at := quietStamp(base.End.NS + 10e6)
	write := func(r QuietReceipt) {
		mustWrite(t, filepath.Join(dir, "quiet-start.json"), jsonBytes(r))
		b := bound(t, filepath.Join(dir, "quiet-start.json"))
		q.QuietStart = &b
	}
	write(base)
	if err := checkQuietLaunch(m, hash, q, at); err != nil {
		t.Fatal(err)
	}
	start := AttemptStart{ID: q.Attempt, Replication: 1, Arm: "N", ManifestSHA256: hash, At: base.Begin}
	end := AttemptEnd{Begin: at}
	phase := Cost{ID: q.Attempt + "-quiet-start", Attempt: q.Attempt, Purpose: "quiet-start", Replication: 1, Arm: "N", StartNS: base.Begin.NS, EndNS: base.End.NS}
	if err := checkQuietAttempt(m, start, end, q, at, map[string]Cost{phase.ID: phase}); err != nil {
		t.Fatal(err)
	}
	for name, phases := range map[string]map[string]Cost{
		"missing-phase":  {},
		"late-preflight": {phase.ID: phase, q.Attempt + "-preflight": {EndNS: phase.StartNS + 1}},
		"late-worker":    {phase.ID: phase, q.Attempt + "-containment": {EndNS: phase.StartNS + 1}},
	} {
		t.Run(name, func(t *testing.T) {
			if checkQuietAttempt(m, start, end, q, at, phases) == nil {
				t.Fatal("invalid preparation order accepted")
			}
		})
	}
	inside := phase
	inside.EndNS = at.NS + 1
	if checkQuietAttempt(m, start, end, q, at, map[string]Cost{phase.ID: inside}) == nil {
		t.Fatal("wait hidden inside request accepted")
	}
	for name, change := range map[string]func(*QuietReceipt){"attempt": func(r *QuietReceipt) { r.Attempt = "r1-001-g0-N" }, "manifest": func(r *QuietReceipt) { r.ManifestSHA256 = strings.Repeat("b", 64) }, "timeout": func(r *QuietReceipt) { r.Decision = "NOT_QUIET_TIMEOUT" }, "deadline": func(r *QuietReceipt) { r.DeadlineNS = r.End.NS }, "future": func(r *QuietReceipt) { r.End.NS = at.NS + 1 }} {
		t.Run(name, func(t *testing.T) {
			r := base
			change(&r)
			write(r)
			if checkQuietLaunch(m, hash, q, at) == nil {
				t.Fatal("forged permit accepted")
			}
		})
	}
	write(base)
	if checkQuietLaunch(m, hash, q, quietStamp(base.End.NS+1e9)) == nil {
		t.Fatal("stale last sample refreshed by receipt end")
	}
	expired := base
	expired.DeadlineNS = at.NS
	write(expired)
	if checkQuietLaunch(m, hash, q, at) == nil {
		t.Fatal("allocation expired between observation and launch")
	}
	wrongBoot := base
	wrongBoot.Samples = append([]PressureSample{}, base.Samples...)
	for i := range wrongBoot.Samples {
		wrongBoot.Samples[i].Begin.Boot = "earlier-boot"
		wrongBoot.Samples[i].End.Boot = "earlier-boot"
	}
	write(wrongBoot)
	if checkQuietLaunch(m, hash, q, at) == nil {
		t.Fatal("another boot's samples admitted")
	}
	q.QuietStart = nil
	if checkQuietLaunch(m, hash, q, at) == nil {
		t.Fatal("missing permit accepted")
	}
}

func TestQuietActualLinuxPressureRead(t *testing.T) {
	s, err := readPressure()
	if err != nil {
		t.Fatal(err)
	}
	if checkStampInterval(s.Begin, s.End) != nil || len(s.TotalsUS) != 3 {
		t.Fatal("incomplete real pressure snapshot")
	}
}

func TestRecorderMeasuresParentWork(t *testing.T) {
	m := fixtureManifest(t, 1)
	enableQuiet(t, &m)
	if err := os.MkdirAll(filepath.Join(m.RunRoot, "costs"), 0700); err != nil {
		t.Fatal(err)
	}
	r := &runner{manifest: m}
	if err := r.phase(Cost{ID: "r1-000-g0-N-capture", Class: "research", Purpose: "complete-output-state-and-invocation-capture", Replication: 1, Ordinal: 0, Arm: "N", Attempt: "r1-000-g0-N"}, func() error { return os.WriteFile(filepath.Join(m.RunRoot, "payload"), make([]byte, 1<<20), 0600) }); err != nil {
		t.Fatal(err)
	}
	costs, err := loadCosts(m.RunRoot)
	if err != nil {
		t.Fatal(err)
	}
	if err := checkRecorderResources(m, costs); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(m.RunRoot, "recorder-resources", "r1-000-g0-N-capture.json")
	var record RecorderResources
	if err := readJSON(path, &record); err != nil {
		t.Fatal(err)
	}
	if record.After.IO["wchar"]-record.Before.IO["wchar"] < 1<<20 {
		t.Fatal("parent write missing")
	}
	record.After.IO["write_bytes"] = -1
	mustWrite(t, path, jsonBytes(record))
	if checkRecorderResources(m, costs) == nil {
		t.Fatal("negative recorder delta accepted")
	}
}

func TestQuietOwnerAdmissionRequiresNewProof(t *testing.T) {
	m := fixtureManifest(t, 4)
	enableQuiet(t, &m)
	m.Driver = "GRADLE"
	proof := filepath.Join(filepath.Dir(m.RunRoot), "synthetic-unit-proof.log")
	mustWrite(t, proof, []byte("unit admission fixture, not owner qualification\n"))
	checks := map[string]Binding{}
	for _, name := range []string{"invocation-output", "failure-fallback", "cancellation-closure", "source-drift", "missing-result", "readiness-admission", "affinity"} {
		checks[name] = bound(t, proof)
	}
	local := ResearchLocalProof{Schema: "buildopt.lean-research/local-proof/v1", Executable: m.Executable, Package: m.Package, Checks: checks}
	localPath := filepath.Join(filepath.Dir(m.RunRoot), "local.json")
	path := filepath.Join(filepath.Dir(m.RunRoot), "readiness.json")
	set := func() {
		mustWrite(t, localPath, jsonBytes(local))
		r := ResearchReadiness{Schema: "buildopt.lean-research/readiness/v1", Mode: leanResearchMode, Identity: researchIdentity(m), LocalProof: bound(t, localPath)}
		mustWrite(t, path, jsonBytes(r))
		b := bound(t, path)
		m.MeasurementReadiness = &b
	}
	for _, name := range []string{"quiet-start-window", "quiet-start-launch", "quiet-start-failures", "recorder-resources"} {
		set()
		if err := validateResearchMeasurement(m); err == nil || !strings.Contains(err.Error(), name) {
			t.Fatalf("missing %s admitted: %v", name, err)
		}
		checks[name] = bound(t, proof)
	}
	set()
	if err := validateResearchMeasurement(m); err != nil {
		t.Fatal(err)
	}
	m.Phase = "ENGINEERING"
	if err := validateResearchMeasurement(m); err == nil || !strings.Contains(err.Error(), "control") {
		t.Fatalf("new local proof substituted for fresh control: %v", err)
	}
}
