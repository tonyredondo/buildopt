//go:build linux && amd64

package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// Quiet admission is experiment preparation. It neither drops completed
// builds nor changes the native command or its request-time boundary.
type QuietPolicy struct {
	Schema             string `json:"schema"`
	WindowNS           int64  `json:"windowNS"`
	SampleNS           int64  `json:"sampleNS"`
	MaximumGapNS       int64  `json:"maximumGapNS"`
	MaximumReadNS      int64  `json:"maximumReadNS"`
	MaximumPressurePPM int64  `json:"maximumPressurePPM"`
	MaximumWaitNS      int64  `json:"maximumWaitNS"`
	MaximumLaunchAgeNS int64  `json:"maximumLaunchAgeNS"`
}

func fixedQuietPolicy() QuietPolicy {
	return QuietPolicy{"buildopt.quiet-start/policy/v1", 30e9, 1e9, 3e9, 100e6, 100000, 180e9, 1e9}
}

func readQuietPolicy(m Manifest) (QuietPolicy, error) {
	var p QuietPolicy
	if m.QuietStart == nil {
		return p, nil
	}
	if m.Mode != leanResearchMode {
		return p, errors.New("quiet start is only supported in lean research")
	}
	if err := validateBinding(*m.QuietStart); err != nil {
		return p, err
	}
	if err := readJSON(m.QuietStart.Path, &p); err != nil {
		return p, err
	}
	if p != fixedQuietPolicy() {
		return p, errors.New("quiet-start policy differs from the fixed v1 conditions")
	}
	return p, nil
}

type PressureSample struct {
	Begin    Stamp            `json:"begin"`
	End      Stamp            `json:"end"`
	TotalsUS map[string]int64 `json:"totalsUS"`
}

type QuietReceipt struct {
	Schema         string            `json:"schema"`
	Attempt        string            `json:"attempt"`
	ManifestSHA256 string            `json:"manifestSHA256"`
	Policy         Binding           `json:"policy"`
	Begin          Stamp             `json:"begin"`
	End            Stamp             `json:"end"`
	DeadlineNS     int64             `json:"deadlineNS"`
	Decision       string            `json:"decision"`
	Reason         string            `json:"reason"`
	Samples        []PressureSample  `json:"samples"`
	CPUStart       diagnosticCPUTime `json:"cpuStart"`
	CPUEnd         diagnosticCPUTime `json:"cpuEnd"`
}

type QuietRejection struct {
	Schema         string `json:"schema"`
	Attempt        string `json:"attempt"`
	ManifestSHA256 string `json:"manifestSHA256"`
	At             Stamp  `json:"at"`
	Reason         string `json:"reason"`
}

func pressureTotal(raw string) (int64, error) {
	for _, line := range strings.Split(raw, "\n") {
		fields := strings.Fields(line)
		if len(fields) == 0 || fields[0] != "some" {
			continue
		}
		var value int64
		found := false
		for _, field := range fields[1:] {
			if strings.HasPrefix(field, "total=") {
				if found {
					return 0, errors.New("duplicate pressure total")
				}
				n, err := strconv.ParseInt(strings.TrimPrefix(field, "total="), 10, 64)
				if err != nil || n < 0 {
					return 0, errors.New("invalid pressure total")
				}
				value, found = n, true
			}
		}
		if found {
			return value, nil
		}
	}
	return 0, errors.New("missing pressure some total")
}

func readPressure() (PressureSample, error) {
	s := PressureSample{Begin: stamp(), TotalsUS: map[string]int64{}}
	for _, resource := range []string{"cpu", "io", "memory"} {
		raw, err := os.ReadFile("/proc/pressure/" + resource)
		if err != nil {
			return s, err
		}
		n, err := pressureTotal(string(raw))
		if err != nil {
			return s, err
		}
		s.TotalsUS[resource] = n
	}
	s.End = stamp()
	return s, nil
}

// Use complete observed intervals, including the interval crossing the window
// boundary. A delayed read cannot become a fresh quiet observation.
func quietWindow(samples []PressureSample, p QuietPolicy) (bool, string) {
	if len(samples) == 0 {
		return false, "no observations"
	}
	last := samples[len(samples)-1]
	first := -1
	for i := len(samples) - 1; i >= 0; i-- {
		if samples[i].End.NS <= last.End.NS-p.WindowNS {
			first = i
			break
		}
	}
	if first < 0 {
		return false, "window incomplete"
	}
	for i := first; i < len(samples); i++ {
		s := samples[i]
		if checkStampInterval(s.Begin, s.End) != nil || s.End.Boot != last.End.Boot || s.End.NS-s.Begin.NS > p.MaximumReadNS {
			return false, "pressure read delayed or clock changed"
		}
		if len(s.TotalsUS) != 3 {
			return false, "missing pressure counters"
		}
		for _, resource := range []string{"cpu", "io", "memory"} {
			n, ok := s.TotalsUS[resource]
			if !ok || n < 0 {
				return false, "invalid pressure counters"
			}
			if i == first {
				continue
			}
			prev := samples[i-1]
			gap := s.End.NS - prev.End.NS
			if gap <= 0 || gap > p.MaximumGapNS || s.Begin.NS < prev.End.NS {
				return false, "sample gap or clock discontinuity"
			}
			delta := n - prev.TotalsUS[resource]
			if delta < 0 {
				return false, "pressure counter reset"
			}
			// Fixed 10% threshold: microseconds * 1000 / nanoseconds <= 1/10.
			// Division avoids overflow if a malformed counter jumps very far.
			if delta > gap/10000 {
				return false, "pressure in window"
			}
		}
	}
	return true, "quiet window"
}

type quietClock struct {
	now  func() Stamp
	read func() (PressureSample, error)
	wait func(context.Context, time.Duration) error
}

func waitQuiet(ctx context.Context, d time.Duration) error {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}

func observeQuiet(ctx context.Context, receipt QuietReceipt, p QuietPolicy, clock quietClock, guard func() error) QuietReceipt {
	receipt.Decision = "NOT_QUIET_TIMEOUT"
	receipt.Samples = []PressureSample{}
	receipt.CPUStart = diagnosticCPU()
	for {
		now := clock.now()
		if now.Boot != receipt.Begin.Boot || now.NS < receipt.Begin.NS {
			receipt.Decision, receipt.Reason = "OBSERVATION_FAILED", "clock changed"
			break
		}
		if now.NS >= receipt.DeadlineNS {
			receipt.Reason = "quiet-start deadline"
			break
		}
		if err := ctx.Err(); err != nil {
			receipt.Decision, receipt.Reason = "INTERRUPTED", err.Error()
			break
		}
		if err := guard(); err != nil {
			receipt.Decision, receipt.Reason = "NOT_RUN_LIMIT", err.Error()
			break
		}
		sample, err := clock.read()
		if err != nil {
			receipt.Decision, receipt.Reason = "OBSERVATION_FAILED", err.Error()
			break
		}
		receipt.Samples = append(receipt.Samples, sample)
		if len(receipt.Samples) > 181 {
			receipt.Decision, receipt.Reason = "OBSERVATION_FAILED", "observation count exceeded"
			break
		}
		ready, reason := quietWindow(receipt.Samples, p)
		receipt.Reason = reason
		if clock.now().NS >= receipt.DeadlineNS {
			receipt.Reason = "quiet-start deadline"
			break
		}
		if err := ctx.Err(); err != nil {
			receipt.Decision, receipt.Reason = "INTERRUPTED", err.Error()
			break
		}
		if ready {
			receipt.Decision = "QUIET_START"
			break
		}
		remaining := receipt.DeadlineNS - clock.now().NS
		if remaining <= 0 {
			break
		}
		if remaining > p.SampleNS {
			remaining = p.SampleNS
		}
		if err := clock.wait(ctx, time.Duration(remaining)); err != nil {
			receipt.Decision, receipt.Reason = "INTERRUPTED", err.Error()
			break
		}
	}
	receipt.End, receipt.CPUEnd = clock.now(), diagnosticCPU()
	return receipt
}

func (r *runner) quietGuard() error {
	if stamp().Boot != r.start.Boot || stamp().NS-r.start.NS >= r.manifest.Limits.MaxRunNS {
		return errors.New("elapsed allocation")
	}
	deadline, err := time.Parse(time.RFC3339Nano, r.manifest.Limits.DeadlineUTC)
	if err != nil {
		return err
	}
	if !time.Now().Before(deadline) {
		return errors.New("allocation deadline")
	}
	return freeDiskGuard(r.manifest.RunRoot, r.manifest.Limits.MinimumFreeBytes)
}

func (r *runner) prepareQuiet(rep, ordinal int, arm, id, evidence string) (*Binding, error) {
	if r.manifest.QuietStart == nil {
		return nil, nil
	}
	policy, err := readQuietPolicy(r.manifest)
	if err != nil {
		return nil, err
	}
	var binding Binding
	err = r.phase(Cost{ID: id + "-quiet-start", Class: "research", Purpose: "quiet-start", Replication: rep, Ordinal: ordinal, Arm: arm, Attempt: id}, func() error {
		begin := stamp()
		deadline := begin.NS + policy.MaximumWaitNS
		if limit := r.start.NS + r.manifest.Limits.MaxRunNS; deadline > limit {
			deadline = limit
		}
		utcDeadline, e := time.Parse(time.RFC3339Nano, r.manifest.Limits.DeadlineUTC)
		if e != nil {
			return e
		}
		if limit := begin.NS + time.Until(utcDeadline).Nanoseconds(); deadline > limit {
			deadline = limit
		}
		receipt := QuietReceipt{Schema: "buildopt.quiet-start/receipt/v1", Attempt: id, ManifestSHA256: r.binding.SHA256, Policy: *r.manifest.QuietStart, Begin: begin, DeadlineNS: deadline}
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
		defer stop()
		clock := quietClock{stamp, readPressure, waitQuiet}
		if r.quietClock != nil {
			clock = *r.quietClock
		}
		if r.quietContext != nil {
			ctx = r.quietContext
		}
		receipt = observeQuiet(ctx, receipt, policy, clock, r.quietGuard)
		var saveErr error
		binding, saveErr = saveBound(filepath.Join(evidence, "quiet-start.json"), receipt)
		if saveErr != nil {
			return saveErr
		}
		if receipt.Decision != "QUIET_START" {
			return fmt.Errorf("NOT_RUN_QUIET: %s: %s", receipt.Decision, receipt.Reason)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return &binding, nil
}

func checkQuietLaunch(m Manifest, manifestHash string, q ProcessRequest, at Stamp) error {
	if m.QuietStart == nil {
		if q.QuietStart != nil {
			return errors.New("unexpected quiet-start receipt")
		}
		return nil
	}
	if q.QuietStart == nil || q.QuietStart.Path != filepath.Join(q.Evidence, "quiet-start.json") {
		return errors.New("missing quiet-start receipt for request")
	}
	policy, err := readQuietPolicy(m)
	if err != nil {
		return err
	}
	if err = validateBinding(*q.QuietStart); err != nil {
		return err
	}
	var receipt QuietReceipt
	if err = readJSON(q.QuietStart.Path, &receipt); err != nil {
		return err
	}
	if at.NS == 0 {
		at = stamp()
	}
	if receipt.Schema != "buildopt.quiet-start/receipt/v1" || receipt.Attempt != q.Attempt || receipt.ManifestSHA256 != manifestHash || receipt.Policy != *m.QuietStart || receipt.Decision != "QUIET_START" || len(receipt.Samples) > 181 {
		return errors.New("quiet-start receipt belongs to another request or did not pass")
	}
	if checkStampInterval(receipt.Begin, receipt.End) != nil || at.NS >= receipt.DeadlineNS || receipt.DeadlineNS-receipt.Begin.NS > policy.MaximumWaitNS || receipt.End.NS > at.NS || at.Boot != receipt.End.Boot {
		return errors.New("quiet-start receipt has invalid boundaries")
	}
	previousEnd := receipt.Begin.NS
	for _, sample := range receipt.Samples {
		if checkStampInterval(sample.Begin, sample.End) != nil || sample.Begin.Boot != receipt.Begin.Boot || sample.Begin.NS < previousEnd || sample.End.NS > receipt.End.NS {
			return errors.New("quiet-start sample lies outside its observation")
		}
		previousEnd = sample.End.NS
	}
	ready, _ := quietWindow(receipt.Samples, policy)
	if !ready {
		return errors.New("quiet-start samples do not establish a quiet window")
	}
	last := receipt.Samples[len(receipt.Samples)-1].End
	if receipt.Samples[0].Begin.NS < receipt.Begin.NS || last.NS > receipt.End.NS || at.NS-last.NS > policy.MaximumLaunchAgeNS {
		return errors.New("NOT_RUN_QUIET: stale observation at launch")
	}
	return nil
}

func checkQuietAttempt(m Manifest, start AttemptStart, end AttemptEnd, q ProcessRequest, nativeStart Stamp, costs map[string]Cost) error {
	if err := checkQuietLaunch(m, start.ManifestSHA256, q, nativeStart); err != nil {
		return err
	}
	if m.QuietStart == nil {
		return nil
	}
	id := start.ID + "-quiet-start"
	if err := requirePhase(costs, id, "quiet-start", start.Replication, start.Ordinal, start.Arm); err != nil {
		return err
	}
	cost := costs[id]
	var receipt QuietReceipt
	if err := readJSON(q.QuietStart.Path, &receipt); err != nil {
		return err
	}
	if cost.Attempt != start.ID || receipt.Begin.NS < cost.StartNS || receipt.End.NS > cost.EndNS || cost.EndNS > end.Begin.NS || cost.StartNS < start.At.NS {
		return errors.New("quiet-start wait is missing or inside the request timing")
	}
	for _, suffix := range []string{"-preflight", "-containment"} {
		if phase, ok := costs[start.ID+suffix]; ok && phase.EndNS > cost.StartNS {
			return errors.New("quiet start preceded expensive preparation")
		}
	}
	return nil
}
