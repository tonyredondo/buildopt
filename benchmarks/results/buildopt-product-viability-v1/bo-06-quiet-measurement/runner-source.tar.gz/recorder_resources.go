//go:build linux && amd64

package main

import (
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// These counters belong only to the outer recorder process. Child processes
// and worker services have their own observations; none is invented as zero.
type RecorderSample struct {
	Begin      Stamp             `json:"begin"`
	End        Stamp             `json:"end"`
	PID        int               `json:"pid"`
	StartTicks uint64            `json:"startTicks"`
	CPU        diagnosticCPUTime `json:"cpu"`
	IO         map[string]int64  `json:"io"`
}

type RecorderResources struct {
	Schema string         `json:"schema"`
	Phase  string         `json:"phase"`
	Before RecorderSample `json:"before"`
	After  RecorderSample `json:"after"`
}

func observeRecorder() (RecorderSample, error) {
	s := RecorderSample{Begin: stamp(), IO: map[string]int64{}, CPU: diagnosticCPU()}
	identity, err := processIdentity(os.Getpid())
	if err != nil {
		return s, err
	}
	s.PID, s.StartTicks = identity.PID, identity.StartTicks
	raw, err := os.ReadFile("/proc/self/io")
	if err != nil {
		return s, err
	}
	for _, line := range strings.Split(string(raw), "\n") {
		fields := strings.Fields(line)
		if len(fields) != 2 {
			continue
		}
		key := strings.TrimSuffix(fields[0], ":")
		if _, exists := s.IO[key]; exists {
			return s, errors.New("duplicate recorder I/O counter")
		}
		n, err := strconv.ParseInt(fields[1], 10, 64)
		if err != nil || n < 0 {
			return s, errors.New("invalid recorder I/O counter")
		}
		s.IO[key] = n
	}
	s.End = stamp()
	for _, name := range []string{"rchar", "wchar", "syscr", "syscw", "read_bytes", "write_bytes", "cancelled_write_bytes"} {
		if _, ok := s.IO[name]; !ok {
			return s, errors.New("missing recorder I/O counter")
		}
	}
	return s, nil
}

func (r *runner) saveRecorderResources(id string, before RecorderSample) error {
	after, err := observeRecorder()
	if err != nil {
		return err
	}
	path := filepath.Join(r.manifest.RunRoot, "recorder-resources")
	if err := os.MkdirAll(path, 0700); err != nil {
		return err
	}
	_, err = saveBound(filepath.Join(path, id+".json"), RecorderResources{"buildopt.recorder-resources/v1", id, before, after})
	return err
}

func checkRecorderResources(m Manifest, costs []Cost) error {
	if m.QuietStart == nil {
		return nil
	}
	for _, cost := range costs {
		if cost.Purpose == "complete-request" {
			continue
		}
		var record RecorderResources
		if err := readJSON(filepath.Join(m.RunRoot, "recorder-resources", cost.ID+".json"), &record); err != nil {
			return err
		}
		a, b := record.Before, record.After
		if record.Schema != "buildopt.recorder-resources/v1" || record.Phase != cost.ID || a.PID <= 0 || a.PID != b.PID || a.StartTicks == 0 || a.StartTicks != b.StartTicks || checkStampInterval(a.Begin, a.End) != nil || checkStampInterval(b.Begin, b.End) != nil || a.End.Boot != b.Begin.Boot || a.End.NS > cost.StartNS || b.Begin.NS < cost.EndNS || b.CPU.UserNS < a.CPU.UserNS || b.CPU.SystemNS < a.CPU.SystemNS {
			return errors.New("recorder resource boundaries or identity differ")
		}
		if len(a.IO) != 7 || len(b.IO) != 7 {
			return errors.New("incomplete recorder I/O counters")
		}
		for _, name := range []string{"rchar", "wchar", "syscr", "syscw", "read_bytes", "write_bytes", "cancelled_write_bytes"} {
			x, xok := a.IO[name]
			y, yok := b.IO[name]
			if !xok || !yok || x < 0 || y < x {
				return errors.New("invalid recorder I/O delta")
			}
		}
	}
	return nil
}
