//go:build linux && amd64

package main

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
)

// Lean research retains the output recorder in both arms. Its timings support
// that recorded workflow only. Samples are diagnostic, not an isolation proof.
const leanResearchMode = "P_LEAN_RESEARCH_V1"

type ResearchReadiness struct {
	Schema       string              `json:"schema"`
	Mode         string              `json:"mode"`
	Identity     string              `json:"identity"`
	LocalProof   Binding             `json:"localProof"`
	ControlProof *ResearchTrialProof `json:"controlProof,omitempty"`
	PrefixProof  *ResearchTrialProof `json:"prefixProof,omitempty"`
}
type ResearchLocalProof struct {
	Schema      string             `json:"schema"`
	ExitCode    int                `json:"exitCode"`
	Executable  Binding            `json:"executable"`
	Package     []Binding          `json:"package"`
	Checks      map[string]Binding `json:"checks"`
	OwnerStarts int                `json:"ownerStarts"`
}
type ResearchTrialProof struct {
	Manifest         Binding `json:"manifest"`
	Result           Binding `json:"result"`
	Closure          Binding `json:"closure"`
	Costs            Binding `json:"costs"`
	OutsideRequestNS int64   `json:"outsideRequestNS"`
}
type ResearchClosure struct {
	Schema           string    `json:"schema"`
	ManifestSHA256   string    `json:"manifestSHA256"`
	ExitCode         int       `json:"exitCode"`
	LivePairs        int       `json:"livePairs"`
	IndependentPairs int       `json:"independentPairs"`
	Closed           bool      `json:"closed"`
	Evidence         []Binding `json:"evidence"`
}

func researchIdentity(m Manifest) string {
	identity := map[string]any{"mode": m.Mode, "protocol": m.Protocol, "executable": m.Executable, "package": m.Package,
		"commonGit": m.CommonGit, "command": m.Command, "environment": m.Environment, "runtime": m.Runtime,
		"baseline": m.Baseline, "candidate": m.Candidate, "outputs": m.Outputs, "acquisition": m.Acquisition,
		"generatedPaths": m.GeneratedPaths, "affinity": m.Affinity, "daemonPolicy": m.DaemonPolicy}
	if m.QuietStart != nil {
		identity["quietStart"] = *m.QuietStart
	}
	return objectDigest(identity)
}

func validateResearchMeasurement(m Manifest) error {
	if _, err := readQuietPolicy(m); err != nil {
		return err
	}
	if m.Mode != leanResearchMode {
		if m.MeasurementReadiness != nil {
			return errors.New("research readiness supplied to another mode")
		}
		return nil
	}
	for _, value := range append(append([]string{}, m.Command...), mapValues(m.Environment)...) {
		for _, flag := range []string{"-javaagent", "-agentlib", "-agentpath"} {
			if strings.Contains(value, flag) {
				return errors.New("lean research forbids diagnostic Java agents")
			}
		}
	}
	if m.Driver == "FIXTURE" && m.Phase == "QUALIFICATION" && m.MeasurementReadiness == nil {
		return nil
	}
	if m.MeasurementReadiness == nil {
		return errors.New("lean research missing its own readiness receipt")
	}
	if err := validateBinding(*m.MeasurementReadiness); err != nil {
		return err
	}
	var r ResearchReadiness
	if err := readJSON(m.MeasurementReadiness.Path, &r); err != nil {
		return err
	}
	if r.Schema != "buildopt.lean-research/readiness/v1" || r.Mode != leanResearchMode || r.Identity != researchIdentity(m) {
		return errors.New("lean research readiness does not bind this implementation and workflow")
	}
	if err := validateBinding(r.LocalProof); err != nil {
		return err
	}
	var local ResearchLocalProof
	if err := readJSON(r.LocalProof.Path, &local); err != nil {
		return err
	}
	if local.Schema != "buildopt.lean-research/local-proof/v1" || local.ExitCode != 0 || local.OwnerStarts != 0 || local.Executable != m.Executable || !reflect.DeepEqual(local.Package, m.Package) {
		return errors.New("lean research local qualification differs or failed")
	}
	requiredChecks := []string{"invocation-output", "failure-fallback", "cancellation-closure", "source-drift", "missing-result", "readiness-admission", "affinity"}
	if m.QuietStart != nil {
		requiredChecks = append(requiredChecks, "quiet-start-window", "quiet-start-launch", "quiet-start-failures", "recorder-resources")
	}
	for _, name := range requiredChecks {
		b, ok := local.Checks[name]
		if !ok {
			return fmt.Errorf("missing local qualification: %s", name)
		}
		if err := validateBinding(b); err != nil {
			return err
		}
	}
	if m.Phase == "ENGINEERING" || m.Phase == "CONFIRMATION" {
		if err := validateResearchTrial(m, r.ControlProof, true); err != nil {
			return err
		}
	}
	if m.Phase == "CONFIRMATION" {
		if err := validateResearchTrial(m, r.PrefixProof, false); err != nil {
			return err
		}
	}
	return nil
}
func mapValues(m map[string]string) []string {
	v := []string{}
	for _, s := range m {
		v = append(v, s)
	}
	return v
}

// Admission reads already reconstructed results; it never starts another
// comparison JVM. The closure receipt binds the live and independent checks.
func validateResearchTrial(m Manifest, p *ResearchTrialProof, control bool) error {
	if p == nil {
		return errors.New("lean research missing required control or prefix proof")
	}
	for _, b := range []Binding{p.Manifest, p.Result, p.Closure, p.Costs} {
		if err := validateBinding(b); err != nil {
			return err
		}
	}
	var prior Manifest
	var result RunResult
	var closure ResearchClosure
	if err := readJSON(p.Manifest.Path, &prior); err != nil {
		return err
	}
	if err := readJSON(p.Result.Path, &result); err != nil {
		return err
	}
	if err := readJSON(p.Closure.Path, &closure); err != nil {
		return err
	}
	costs, err := loadCosts(prior.RunRoot)
	if err != nil {
		return err
	}
	if p.Costs.Path != prior.RunRoot+"/costs" {
		return errors.New("trial cost ledger differs")
	}
	var outside int64
	for _, c := range costs {
		if c.Class == "customer-machine" && !c.InsideEnvelope {
			outside += c.DurationNS
		}
	}
	if outside != p.OutsideRequestNS {
		return errors.New("trial outside-request cost differs")
	}
	slots := 21
	if control {
		slots = 4
	}
	if researchIdentity(prior) != researchIdentity(m) || prior.Replications != 1 || prior.ExecutionEnd != slots-1 || result.Schema != resultSchema || result.ManifestSHA256 != p.Manifest.SHA256 || result.WorkflowStarts != 2*slots || result.ActualGradleStarts != 2*slots || result.UnknownGradleReservations != 0 || result.NestedStarts != 0 || len(result.Slots) != 1 || len(result.Slots[0]) != slots {
		return errors.New("lean research trial scope, sources or completeness differs")
	}
	if len(m.History) != 101 {
		return errors.New("research admission needs complete frozen history")
	}
	for ordinal, row := range prior.History[:slots] {
		expected := ordinal
		if control {
			expected += 17
		}
		want := m.History[expected]
		want.Ordinal = row.Ordinal
		if !reflect.DeepEqual(want, row) {
			return errors.New("trial used another history window")
		}
	}
	if control {
		combined := prior.Baseline
		combined.Files = append(append([]FilePatch{}, prior.Baseline.Files...), prior.Candidate.Files...)
		if prior.ControlBaseline == nil || !reflect.DeepEqual(prior.ControlBaseline.Files, combined.Files) || prior.Phase != "QUALIFICATION" {
			return errors.New("research control is not identical code")
		}
	} else if prior.ControlBaseline != nil || prior.Phase != "ENGINEERING" || prior.PrefixEnd != 20 || len(prior.History) != 101 {
		return errors.New("research prefix scope differs")
	}
	if closure.Schema != "buildopt.lean-research/closure/v1" || closure.ManifestSHA256 != p.Manifest.SHA256 || closure.ExitCode != 0 || !closure.Closed || closure.LivePairs != slots || closure.IndependentPairs != slots || len(closure.Evidence) == 0 {
		return errors.New("research comparison or process closure incomplete")
	}
	for _, b := range closure.Evidence {
		if err := validateBinding(b); err != nil {
			return err
		}
	}
	var n, i int64
	for ordinal, s := range result.Slots[0] {
		if s.Ordinal != ordinal || !isComparable(s) || s.NativeNS <= 0 || s.CandidateNS <= 0 || s.ExtraCandidateNS != 0 {
			return errors.New("research trial contains invalid or unavailable result")
		}
		if ordinal > 0 {
			n += s.NativeNS
			i += s.CandidateNS
		}
	}
	if p.OutsideRequestNS < 0 {
		return errors.New("negative research preparation cost")
	}
	if control {
		difference := n - i
		if difference < 0 {
			difference = -difference
		}
		faster := n
		if i < faster {
			faster = i
		}
		if difference >= 3e9 && float64(difference) >= 0.05*float64(faster) {
			return errors.New("identical-code control produced a material difference")
		}
	} else {
		saving := n - i - p.OutsideRequestNS
		if saving < 20e9 || float64(saving) < 0.05*float64(n) {
			return errors.New("development prefix did not save enough time")
		}
	}
	return nil
}
