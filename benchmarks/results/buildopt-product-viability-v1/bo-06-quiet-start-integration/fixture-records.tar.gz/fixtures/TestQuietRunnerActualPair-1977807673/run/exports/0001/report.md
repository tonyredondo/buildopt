# Historical replay result

Decision: `FIXTURE_VERIFIED`. Phase: `QUALIFICATION`. Subject: `local-fixture`.

Workflows started: 2. Gradle invocations observed: 0, including 0 nested. Reserved Gradle starts: 0; unresolved reservations: 0.

| Replication | Complete | Comparable / scheduled | Net seconds | Net percent | Payback ordinal | Research seconds | Study elapsed seconds |
|---|---|---|---|---|---|---|---|
| 1 | true | 0 / 0 | -0.000492 | 0.000 | -1 | 132.575403 | 132.820731 |

Primary requests include candidate admission/application. Research time includes source checkout, evidence capture, synchronization and gaps inside each replication. The final offline checker/export runs after that interval; its command receipt is separate research evidence. Human costs must be reported separately. Qualification and engineering results cannot establish public-repository value.

Raw ledger: [attempts](attempts.jsonl), [costs](costs.jsonl), [manifest](manifest.json), [result](result.json).
